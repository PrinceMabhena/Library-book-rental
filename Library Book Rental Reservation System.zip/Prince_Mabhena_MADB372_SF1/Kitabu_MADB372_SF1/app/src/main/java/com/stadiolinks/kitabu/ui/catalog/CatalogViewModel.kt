package com.stadiolinks.kitabu.ui.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stadiolinks.kitabu.data.local.entity.BookEntity
import com.stadiolinks.kitabu.data.repository.LibraryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CatalogUiState(
    val books: List<BookEntity> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val lastReservedTitle: String? = null
)

/**
 * Owns catalog screen state. Room's Flow queries are converted to a
 * lifecycle-friendly StateFlow using .stateIn() with WhileSubscribed(5000),
 * per the module's Compose integration guidance.
 */
class CatalogViewModel(
    private val repository: LibraryRepository
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")
    private val transientMessage = MutableStateFlow<Pair<String?, String?>>(null to null)

    private val booksFlow = searchQuery.flatMapLatest { query ->
        repository.searchBooks(query)
    }

    val uiState: StateFlow<CatalogUiState> = combineCatalogState()

    private fun combineCatalogState(): StateFlow<CatalogUiState> {
        return kotlinx.coroutines.flow.combine(
            booksFlow,
            searchQuery,
            transientMessage
        ) { books, query, (error, reserved) ->
            CatalogUiState(
                books = books,
                searchQuery = query,
                isLoading = false,
                errorMessage = error,
                lastReservedTitle = reserved
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CatalogUiState()
        )
    }

    fun onSearchQueryChanged(query: String) {
        // Basic input sanitisation (Section D.3): trim, cap length.
        searchQuery.value = query.take(80)
    }

    /** Reserve a book. Runs off the main thread via viewModelScope (Section D.2). */
    fun reserveBook(book: BookEntity, userName: String, rentalDays: Int) {
        viewModelScope.launch {
            try {
                repository.reserveBook(book, userName, rentalDays)
                transientMessage.value = null to book.title
            } catch (e: IllegalArgumentException) {
                transientMessage.value = (e.message ?: "Unable to reserve book.") to null
            }
        }
    }

    fun consumeMessages() {
        transientMessage.value = null to null
    }
}
