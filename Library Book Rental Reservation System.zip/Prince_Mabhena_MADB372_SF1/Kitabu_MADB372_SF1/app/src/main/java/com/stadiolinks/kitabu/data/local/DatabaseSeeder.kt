package com.stadiolinks.kitabu.data.local

import com.stadiolinks.kitabu.data.local.entity.BookEntity

/**
 * Sample catalog data inserted once via KitabuDatabase.Callback.onCreate().
 */
object DatabaseSeeder {

    fun sampleBooks(): List<BookEntity> = listOf(
        BookEntity(title = "Clean Code", author = "Robert C. Martin", category = "Software Engineering"),
        BookEntity(title = "Kotlin in Action", author = "Dmitry Jemerov", category = "Programming"),
        BookEntity(title = "Introduction to Algorithms", author = "Thomas H. Cormen", category = "Computer Science"),
        BookEntity(title = "Database System Concepts", author = "Abraham Silberschatz", category = "Databases"),
        BookEntity(title = "Design Patterns", author = "Erich Gamma", category = "Software Engineering"),
        BookEntity(title = "Computer Networking", author = "James F. Kurose", category = "Networking"),
        BookEntity(title = "Operating System Concepts", author = "Abraham Silberschatz", category = "Computer Science"),
        BookEntity(title = "Mobile App Design Essentials", author = "Laura Klein", category = "UI/UX"),
        BookEntity(title = "The Pragmatic Programmer", author = "David Thomas", category = "Software Engineering"),
        BookEntity(title = "Effective Java", author = "Joshua Bloch", category = "Programming")
    )
}
