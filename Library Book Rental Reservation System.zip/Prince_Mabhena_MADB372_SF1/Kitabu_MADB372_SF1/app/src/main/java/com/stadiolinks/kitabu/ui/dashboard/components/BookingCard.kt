package com.stadiolinks.kitabu.ui.dashboard.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.stadiolinks.kitabu.data.local.entity.BookingStatus
import com.stadiolinks.kitabu.data.local.entity.BookingWithBook
import com.stadiolinks.kitabu.ui.dashboard.daysRemaining
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFormat = SimpleDateFormat("d MMM yyyy", Locale.getDefault())

/**
 * Section A.2 — dashboard item card: book details, reservation date,
 * return deadline, days remaining, and Renew / Return / Cancel controls.
 */
@Composable
fun BookingCard(
    item: BookingWithBook,
    onRenew: (Long) -> Unit,
    onReturn: (Long) -> Unit,
    onCancel: (Long) -> Unit
) {
    val remaining = daysRemaining(item.booking.returnDeadline)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(text = item.author, style = MaterialTheme.typography.bodySmall)

            Text(
                text = "Reserved: ${dateFormat.format(Date(item.booking.bookingDate))}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Due: ${dateFormat.format(Date(item.booking.returnDeadline))}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = if (remaining >= 0) "$remaining day(s) remaining" else "${-remaining} day(s) overdue",
                style = MaterialTheme.typography.bodySmall,
                color = if (remaining < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { onRenew(item.booking.bookingId) }) {
                    Text("Renew")
                }
                OutlinedButton(onClick = { onReturn(item.booking.bookingId) }) {
                    Text("Return")
                }
                if (item.booking.status == BookingStatus.PENDING) {
                    TextButton(onClick = { onCancel(item.booking.bookingId) }) {
                        Text("Cancel")
                    }
                }
            }
        }
    }
}
