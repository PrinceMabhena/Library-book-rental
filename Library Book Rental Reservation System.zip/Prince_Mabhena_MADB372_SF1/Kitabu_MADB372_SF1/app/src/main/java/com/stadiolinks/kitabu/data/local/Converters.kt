package com.stadiolinks.kitabu.data.local

import androidx.room.TypeConverter
import com.stadiolinks.kitabu.data.local.entity.BookingStatus

/**
 * SQLite only understands primitives (Long, String, Int, etc.), so complex
 * Kotlin types used on our entities need explicit converters:
 *  - BookingStatus (enum)      <-> String
 *  - bookingDate / returnDeadline are already stored as Long (epoch millis),
 *    but a Long<->java.util.Date helper is included for convenience if the
 *    UI layer ever needs to work with Date objects directly.
 */
class Converters {

    @TypeConverter
    fun fromBookingStatus(status: BookingStatus): String = status.name

    @TypeConverter
    fun toBookingStatus(value: String): BookingStatus = BookingStatus.valueOf(value)

    @TypeConverter
    fun fromTimestamp(value: Long?): java.util.Date? = value?.let { java.util.Date(it) }

    @TypeConverter
    fun dateToTimestamp(date: java.util.Date?): Long? = date?.time
}
