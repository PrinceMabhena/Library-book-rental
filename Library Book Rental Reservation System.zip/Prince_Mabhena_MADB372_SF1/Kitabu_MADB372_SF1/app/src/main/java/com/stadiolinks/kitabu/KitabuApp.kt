package com.stadiolinks.kitabu

import android.app.Application
import com.stadiolinks.kitabu.di.AppContainer

class KitabuApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
