package com.stadiolinks.kitabu.ui.theme

import androidx.compose.ui.graphics.Color

val KitabuGreen = Color(0xFF2E7D32)
val KitabuGreenLight = Color(0xFFA5D6A7)
val KitabuAmber = Color(0xFFEF6C00)
val KitabuAmberLight = Color(0xFFFFCC80)
val KitabuPrimary = Color(0xFF1B5E20)
val KitabuSecondary = Color(0xFF6D4C41)
val KitabuBackground = Color(0xFFF7F7F5)
val KitabuSurface = Color(0xFFFFFFFF)
val KitabuError = Color(0xFFC62828)
