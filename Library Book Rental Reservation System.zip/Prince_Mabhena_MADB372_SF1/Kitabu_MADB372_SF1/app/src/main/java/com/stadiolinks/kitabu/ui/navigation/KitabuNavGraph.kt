package com.stadiolinks.kitabu.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.stadiolinks.kitabu.ui.ViewModelFactory
import com.stadiolinks.kitabu.ui.catalog.CatalogScreen
import com.stadiolinks.kitabu.ui.dashboard.DashboardScreen

sealed class KitabuDestination(val route: String, val label: String) {
    data object Catalog : KitabuDestination("catalog", "Catalog")
    data object Dashboard : KitabuDestination("dashboard", "My Reservations")
}

private val destinations = listOf(KitabuDestination.Catalog, KitabuDestination.Dashboard)

/**
 * Section A.3 — single-activity navigation using NavHost / composable / NavController.
 */
@Composable
fun KitabuNavGraph(factory: ViewModelFactory) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                destinations.forEach { destination ->
                    val selected = currentDestination?.hierarchy?.any { it.route == destination.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (destination is KitabuDestination.Catalog)
                                    Icons.Default.MenuBook else Icons.Default.List,
                                contentDescription = destination.label
                            )
                        },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = KitabuDestination.Catalog.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(KitabuDestination.Catalog.route) {
                CatalogScreen(factory = factory)
            }
            composable(KitabuDestination.Dashboard.route) {
                DashboardScreen(factory = factory)
            }
        }
    }
}
