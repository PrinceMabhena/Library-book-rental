package com.stadiolinks.kitabu.ui.catalog.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stadiolinks.kitabu.data.local.entity.BookEntity

private val RENTAL_OPTIONS = listOf(7, 14, 21)

/**
 * Section A.1 — Reservation Action: tapping an available book opens this
 * Modal Bottom Sheet with rental duration choices and a Reserve button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReserveBottomSheet(
    book: BookEntity,
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onConfirm: (userName: String, rentalDays: Int) -> Unit
) {
    var userName by remember { mutableStateOf("") }
    var selectedDays by remember { mutableIntStateOf(RENTAL_OPTIONS.first()) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = "Reserve \u201C${book.title}\u201D")

            OutlinedTextField(
                value = userName,
                onValueChange = { userName = it.take(50) }, // sanitise: cap length
                label = { Text("Your name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Text(text = "Rental duration")
            Column {
                RENTAL_OPTIONS.forEach { days ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = (days == selectedDays),
                                onClick = { selectedDays = days }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = (days == selectedDays), onClick = { selectedDays = days })
                        Text(text = "$days days")
                    }
                }
            }

            Button(
                onClick = { onConfirm(userName.trim(), selectedDays) },
                enabled = userName.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Reserve")
            }
        }
    }
}
