package com.stadiolinks.kitabu.data.local.entity

import androidx.room.Embedded

/**
 * Read-model that joins a [BookingEntity] with its parent [BookEntity].
 * Used to power the User Reservations Dashboard, which needs both the
 * booking lifecycle info (dates, status) and the book details (title, author)
 * in a single row without a second round-trip query.
 */
data class BookingWithBook(
    @Embedded
    val booking: BookingEntity,
    val title: String,
    val author: String,
    val category: String
)
