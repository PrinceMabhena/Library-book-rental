package com.stadiolinks.kitabu.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single library title in the Kitabu catalog.
 */
@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey(autoGenerate = true)
    val bookId: Long = 0L,
    val title: String,
    val author: String,
    val category: String,
    val isAvailable: Boolean = true
)
