package com.stadiolinks.kitabu.ui.catalog.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.stadiolinks.kitabu.data.local.entity.BookEntity
import com.stadiolinks.kitabu.ui.theme.KitabuAmber
import com.stadiolinks.kitabu.ui.theme.KitabuGreen

/**
 * Section A.1 — Item Card & Badging.
 * Green badge = Available, Amber/Orange badge = Borrowed.
 */
@Composable
fun BookCard(
    book: BookEntity,
    onClick: (BookEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = { onClick(book) },
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(text = book.title, style = MaterialTheme.typography.titleMedium)
            Text(
                text = book.author,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = book.category,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            AvailabilityBadge(isAvailable = book.isAvailable)
        }
    }
}

@Composable
private fun AvailabilityBadge(isAvailable: Boolean) {
    val (bg, label) = if (isAvailable) {
        KitabuGreen to "Available"
    } else {
        KitabuAmber to "Borrowed"
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(50),
        modifier = Modifier
    ) {
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(PaddingValues(horizontal = 10.dp, vertical = 4.dp))
        )
    }
}
