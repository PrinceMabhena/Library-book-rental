package com.stadiolinks.kitabu.data.repository

import com.stadiolinks.kitabu.data.local.dao.BookDao
import com.stadiolinks.kitabu.data.local.dao.BookingDao
import com.stadiolinks.kitabu.data.local.entity.BookEntity
import com.stadiolinks.kitabu.data.local.entity.BookingEntity
import com.stadiolinks.kitabu.data.local.entity.BookingStatus
import com.stadiolinks.kitabu.data.local.entity.BookingWithBook
import kotlinx.coroutines.flow.Flow

/**
 * Repository layer: the single source of truth the ViewModels talk to.
 * Keeps DAOs/SQL out of the UI/ViewModel layers (clean MVVM separation,
 * Section C) and centralises the booking lifecycle rules (Section B).
 */
class LibraryRepository(
    private val bookDao: BookDao,
    private val bookingDao: BookingDao
) {

    // ---- Catalog ----
    fun getAvailableBooks(): Flow<List<BookEntity>> = bookDao.getAvailableBooks()

    fun getAllBooks(): Flow<List<BookEntity>> = bookDao.getAllBooks()

    fun searchBooks(query: String): Flow<List<BookEntity>> {
        return if (query.isBlank()) bookDao.getAllBooks() else bookDao.searchBooks(query.trim())
    }

    // ---- Dashboard ----
    fun getActiveBookingsWithBookInfo(): Flow<List<BookingWithBook>> =
        bookingDao.getActiveBookingsWithBookInfo()

    // ---- Reservation lifecycle ----

    /**
     * Reserve a book: creates a PENDING booking and immediately flips the
     * book's availability flag so the catalog badge reflects it in real time
     * (Section A.3 — reactive state via Flow).
     */
    suspend fun reserveBook(book: BookEntity, userName: String, rentalDays: Int) {
        require(book.isAvailable) { "Book is not available for reservation." }
        require(userName.isNotBlank()) { "Reservation requires a user name." }
        require(rentalDays > 0) { "Rental duration must be at least 1 day." }

        val now = System.currentTimeMillis()
        val deadline = now + (rentalDays * DAY_IN_MILLIS)

        bookingDao.insertBooking(
            BookingEntity(
                bookOwnerId = book.bookId,
                userName = userName.trim(),
                bookingDate = now,
                returnDeadline = deadline,
                status = BookingStatus.PENDING
            )
        )
        bookDao.setAvailability(book.bookId, isAvailable = false)
    }

    /** Renew: push the return deadline out by [extraDays], validating it's positive. */
    suspend fun renewBooking(bookingId: Long, extraDays: Int) {
        require(extraDays > 0) { "Renewal must extend the deadline by at least 1 day." }
        val booking = bookingDao.getBookingById(bookingId) ?: return
        val newDeadline = booking.returnDeadline + (extraDays * DAY_IN_MILLIS)
        bookingDao.extendDeadline(bookingId, newDeadline)
        if (booking.status == BookingStatus.PENDING) {
            bookingDao.updateStatus(bookingId, BookingStatus.ACTIVE)
        }
    }

    /** Return: closes the booking and frees the book back into the catalog. */
    suspend fun returnBooking(bookingId: Long) {
        val booking = bookingDao.getBookingById(bookingId) ?: return
        bookingDao.updateStatus(bookingId, BookingStatus.RETURNED)
        bookDao.setAvailability(booking.bookOwnerId, isAvailable = true)
    }

    /** Cancel: deletes a PENDING booking outright and frees the book. */
    suspend fun cancelBooking(bookingId: Long) {
        val booking = bookingDao.getBookingById(bookingId) ?: return
        bookingDao.deleteBookingById(bookingId)
        bookDao.setAvailability(booking.bookOwnerId, isAvailable = true)
    }

    companion object {
        private const val DAY_IN_MILLIS = 24L * 60L * 60L * 1000L
    }
}
