package com.stadiolinks.kitabu.ui.catalog

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stadiolinks.kitabu.data.local.entity.BookEntity
import com.stadiolinks.kitabu.ui.ViewModelFactory
import com.stadiolinks.kitabu.ui.catalog.components.BookCard
import com.stadiolinks.kitabu.ui.catalog.components.ReserveBottomSheet
import kotlinx.coroutines.launch

/**
 * Section A.1 — Book Catalog Screen: search + grid + reservation flow.
 * Section A.3 — state observed via collectAsStateWithLifecycle(); badges
 * update immediately because the underlying Flow query re-emits on write.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(
    factory: ViewModelFactory,
    viewModel: CatalogViewModel = viewModel(factory = factory)
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedBook by remember { mutableStateOf<BookEntity?>(null) }
    val sheetState = rememberModalBottomSheetState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.lastReservedTitle, uiState.errorMessage) {
        uiState.lastReservedTitle?.let {
            snackbarHostState.showSnackbar("Reserved \u201C$it\u201D")
            viewModel.consumeMessages()
        }
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.consumeMessages()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            CatalogBody(uiState, viewModel, onBookClick = { selectedBook = it })
        }
    }

    selectedBook?.let { book ->
        ReserveBottomSheet(
            book = book,
            sheetState = sheetState,
            onDismiss = { selectedBook = null },
            onConfirm = { userName, days ->
                viewModel.reserveBook(book, userName, days)
                coroutineScope.launch { sheetState.hide() }
                selectedBook = null
            }
        )
    }
}

@Composable
private fun CatalogBody(
    uiState: CatalogUiState,
    viewModel: CatalogViewModel,
    onBookClick: (BookEntity) -> Unit
) {
    androidx.compose.foundation.layout.Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = viewModel::onSearchQueryChanged,
            label = { Text("Search by title or author") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )

        when {
            uiState.isLoading -> CenteredLoader()
            uiState.books.isEmpty() -> CenteredEmptyState()
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(uiState.books, key = { it.bookId }) { book ->
                    BookCard(
                        book = book,
                        onClick = { if (it.isAvailable) onBookClick(it) },
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CenteredLoader() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun CenteredEmptyState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("No books match your search.")
    }
}
