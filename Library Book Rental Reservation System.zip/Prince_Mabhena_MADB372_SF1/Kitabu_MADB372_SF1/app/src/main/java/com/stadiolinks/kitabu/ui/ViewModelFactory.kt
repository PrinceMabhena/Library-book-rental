package com.stadiolinks.kitabu.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.stadiolinks.kitabu.data.repository.LibraryRepository
import com.stadiolinks.kitabu.ui.catalog.CatalogViewModel
import com.stadiolinks.kitabu.ui.dashboard.DashboardViewModel

/**
 * Minimal factory so CatalogViewModel / DashboardViewModel can take the
 * repository as a constructor parameter without a DI framework.
 */
class ViewModelFactory(
    private val repository: LibraryRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(CatalogViewModel::class.java) ->
                CatalogViewModel(repository) as T
            modelClass.isAssignableFrom(DashboardViewModel::class.java) ->
                DashboardViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
