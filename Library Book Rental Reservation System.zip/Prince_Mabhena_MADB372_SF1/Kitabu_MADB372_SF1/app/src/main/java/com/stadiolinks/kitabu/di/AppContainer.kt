package com.stadiolinks.kitabu.di

import android.content.Context
import com.stadiolinks.kitabu.data.local.KitabuDatabase
import com.stadiolinks.kitabu.data.repository.LibraryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

/**
 * Lightweight manual dependency container (no Hilt/Koin per the "keep
 * dependencies minimal" project scope). Wires Database -> DAOs -> Repository
 * once, at Application level, so every screen shares the same instances.
 */
class AppContainer(context: Context) {

    private val applicationScope = CoroutineScope(SupervisorJob())

    private val database: KitabuDatabase by lazy {
        KitabuDatabase.getInstance(context, applicationScope)
    }

    val repository: LibraryRepository by lazy {
        LibraryRepository(database.bookDao(), database.bookingDao())
    }
}
