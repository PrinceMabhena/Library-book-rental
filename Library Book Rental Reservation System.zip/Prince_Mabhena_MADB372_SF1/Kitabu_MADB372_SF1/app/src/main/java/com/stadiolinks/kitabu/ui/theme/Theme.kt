package com.stadiolinks.kitabu.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = KitabuPrimary,
    secondary = KitabuSecondary,
    background = KitabuBackground,
    surface = KitabuSurface,
    error = KitabuError
)

private val DarkColors = darkColorScheme(
    primary = KitabuGreenLight,
    secondary = KitabuAmberLight,
    background = Color0F,
    surface = Color1A,
    error = KitabuError
)

// Small dark-theme surface colors kept local to avoid extra top-level noise.
private val Color0F = androidx.compose.ui.graphics.Color(0xFF0F1210)
private val Color1A = androidx.compose.ui.graphics.Color(0xFF1A1F1B)

@Composable
fun KitabuTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
