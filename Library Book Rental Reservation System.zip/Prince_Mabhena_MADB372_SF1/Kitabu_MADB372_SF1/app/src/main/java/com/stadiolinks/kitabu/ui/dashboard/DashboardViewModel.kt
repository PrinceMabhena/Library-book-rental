package com.stadiolinks.kitabu.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stadiolinks.kitabu.data.local.entity.BookingWithBook
import com.stadiolinks.kitabu.data.repository.LibraryRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardUiState(
    val bookings: List<BookingWithBook> = emptyList(),
    val isLoading: Boolean = true
)

class DashboardViewModel(
    private val repository: LibraryRepository
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = repository.getActiveBookingsWithBookInfo()
        .map { bookings -> DashboardUiState(bookings = bookings, isLoading = false) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardUiState()
        )

    fun renew(bookingId: Long, extraDays: Int = 7) {
        viewModelScope.launch { repository.renewBooking(bookingId, extraDays) }
    }

    fun returnBook(bookingId: Long) {
        viewModelScope.launch { repository.returnBooking(bookingId) }
    }

    fun cancel(bookingId: Long) {
        viewModelScope.launch { repository.cancelBooking(bookingId) }
    }
}

/** Days remaining until [returnDeadline], rounded up; negative means overdue. */
fun daysRemaining(returnDeadline: Long): Long {
    val diff = returnDeadline - System.currentTimeMillis()
    return kotlin.math.ceil(diff / (24.0 * 60 * 60 * 1000)).toLong()
}
