package com.stadiolinks.kitabu.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.stadiolinks.kitabu.data.local.entity.BookingEntity
import com.stadiolinks.kitabu.data.local.entity.BookingStatus
import com.stadiolinks.kitabu.data.local.entity.BookingWithBook
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {

    // ---- Create ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    // ---- Read ----
    // Active reservations (PENDING or ACTIVE) joined with their book info,
    // powering the User Reservations Dashboard.
    @Transaction
    @Query(
        """
        SELECT bookings.*, books.title AS title, books.author AS author, books.category AS category
        FROM bookings
        INNER JOIN books ON bookings.bookOwnerId = books.bookId
        WHERE bookings.status != 'RETURNED'
        ORDER BY bookings.returnDeadline ASC
        """
    )
    fun getActiveBookingsWithBookInfo(): Flow<List<BookingWithBook>>

    @Query("SELECT * FROM bookings WHERE bookingId = :bookingId LIMIT 1")
    suspend fun getBookingById(bookingId: Long): BookingEntity?

    @Query("SELECT * FROM bookings WHERE bookOwnerId = :bookId AND status != 'RETURNED' LIMIT 1")
    suspend fun getOpenBookingForBook(bookId: Long): BookingEntity?

    // ---- Update ----
    // Extend the rental period (Renew action).
    @Query("UPDATE bookings SET returnDeadline = :newDeadline WHERE bookingId = :bookingId")
    suspend fun extendDeadline(bookingId: Long, newDeadline: Long)

    // Move status forward in the lifecycle (PENDING -> ACTIVE, or -> RETURNED).
    @Query("UPDATE bookings SET status = :status WHERE bookingId = :bookingId")
    suspend fun updateStatus(bookingId: Long, status: BookingStatus)

    // ---- Delete ----
    // Cancel a pending reservation before pickup.
    @Delete
    suspend fun deleteBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE bookingId = :bookingId")
    suspend fun deleteBookingById(bookingId: Long)
}
