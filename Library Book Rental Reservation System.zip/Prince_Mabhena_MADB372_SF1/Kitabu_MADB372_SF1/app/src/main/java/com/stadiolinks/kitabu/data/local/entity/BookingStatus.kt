package com.stadiolinks.kitabu.data.local.entity

/**
 * Lifecycle states for a [BookingEntity].
 *
 * PENDING  -> reservation created, book not yet picked up
 * ACTIVE   -> book has been picked up / rental period is in progress
 * RETURNED -> book has been returned, booking is closed
 */
enum class BookingStatus {
    PENDING,
    ACTIVE,
    RETURNED
}
