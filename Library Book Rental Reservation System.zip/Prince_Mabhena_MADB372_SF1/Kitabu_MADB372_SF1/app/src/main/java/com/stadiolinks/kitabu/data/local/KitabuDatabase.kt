package com.stadiolinks.kitabu.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.stadiolinks.kitabu.data.local.dao.BookDao
import com.stadiolinks.kitabu.data.local.dao.BookingDao
import com.stadiolinks.kitabu.data.local.entity.BookEntity
import com.stadiolinks.kitabu.data.local.entity.BookingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Increment [Database.version] whenever an @Entity changes shape.
 * fallbackToDestructiveMigration() is used during development so schema
 * changes don't crash the app with a missing-migration exception.
 */
@Database(
    entities = [BookEntity::class, BookingEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class KitabuDatabase : RoomDatabase() {

    abstract fun bookDao(): BookDao
    abstract fun bookingDao(): BookingDao

    companion object {
        @Volatile
        private var INSTANCE: KitabuDatabase? = null

        /**
         * Thread-safe singleton accessor. [scope] is used purely to launch the
         * one-off pre-population coroutine from the onCreate callback below —
         * it is NOT how normal DAO calls are made (those always come from
         * viewModelScope in the ViewModel layer, see LibraryRepository).
         */
        fun getInstance(context: Context, scope: CoroutineScope): KitabuDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context, scope).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context, scope: CoroutineScope): KitabuDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                KitabuDatabase::class.java,
                "kitabu.db"
            )
                .fallbackToDestructiveMigration()
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate sample books on first run only.
                        INSTANCE?.let { database ->
                            scope.launch {
                                database.bookDao().insertBooks(DatabaseSeeder.sampleBooks())
                            }
                        }
                    }
                })
                .build()
        }
    }
}
