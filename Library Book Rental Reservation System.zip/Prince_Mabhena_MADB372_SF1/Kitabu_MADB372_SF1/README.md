# Kitabu — Library Book Rental & Reservation System

**Module:** MADB372 (Mobile Application Development B) — Assignment SF1, Task 1
**Student number:** 24301449

Kitabu ("book" in Swahili) is a native Android app for StadioLinks that lets
students browse a library catalog, reserve titles, and manage the full
rental lifecycle (renew, return, cancel) with real-time, offline-first data
backed by Room.

## Tech stack

| Layer | Technology |
|---|---|
| Language | Kotlin |
| UI | Jetpack Compose (Material 3) |
| Navigation | Navigation Compose (single-activity) |
| Local persistence | Room (SQLite), KSP annotation processing |
| Concurrency | Kotlin Coroutines + Flow |
| Architecture | MVVM (UI → ViewModel → Repository → DAO/Entity) |

## Architecture overview

```
ui/
  catalog/        CatalogScreen, CatalogViewModel, BookCard, ReserveBottomSheet
  dashboard/       DashboardScreen, DashboardViewModel, BookingCard
  navigation/      KitabuNavGraph (NavHost / NavController)
  theme/           Material 3 color scheme & theme
  ViewModelFactory.kt

data/
  local/
    entity/        BookEntity, BookingEntity, BookingStatus, BookingWithBook
    dao/            BookDao, BookingDao
    Converters.kt   TypeConverters (enum <-> String, Long <-> Date)
    KitabuDatabase.kt   Room singleton + pre-population callback
    DatabaseSeeder.kt   Sample catalog data
  repository/
    LibraryRepository.kt   Business logic: reserve / renew / return / cancel

di/
  AppContainer.kt   Manual dependency container (Database → DAOs → Repository)

KitabuApp.kt   Application class exposing AppContainer
MainActivity.kt   Single activity; hosts KitabuNavGraph
```

**Data flow:** Room DAOs expose `Flow` queries → `LibraryRepository` exposes
them unchanged (or maps them) → ViewModels convert them to `StateFlow` via
`.stateIn(viewModelScope, WhileSubscribed(5000), initialValue)` → Compose
screens collect with `collectAsStateWithLifecycle()`. Any write (reserve,
renew, return, cancel) re-triggers the Flow automatically, so catalog
badges and the dashboard update immediately without manual refresh calls.

All database writes run inside `viewModelScope.launch { ... }`, so no query
ever touches the main thread.

## Core entities

- **BookEntity** — `bookId` (PK), `title`, `author`, `category`, `isAvailable`
- **BookingEntity** — `bookingId` (PK), `bookOwnerId` (FK → BookEntity.bookId,
  `CASCADE` delete), `userName`, `bookingDate`, `returnDeadline`,
  `status` (`PENDING` / `ACTIVE` / `RETURNED`)

## Reservation lifecycle

1. **Reserve** — creates a `PENDING` `BookingEntity` and flips
   `BookEntity.isAvailable` to `false`.
2. **Renew** — extends `returnDeadline`; also promotes `PENDING` → `ACTIVE`.
3. **Return** — sets booking status to `RETURNED` and flips the book back
   to `isAvailable = true`.
4. **Cancel** — deletes the `PENDING` booking row and frees the book (only
   available before pickup).

## Setup instructions

1. Clone this repository.
2. Open the `Kitabu_MADB372_SF1` folder in Android Studio (Ladybug 2024.2.1
   or newer) — Android Studio will fetch the Gradle wrapper and sync
   dependencies automatically.
3. Ensure the Kotlin plugin, KSP plugin, and an Android SDK with API 35
   installed are available (min SDK 26).
4. Run on an emulator or device running API 26+.
5. On first launch, Room pre-populates the catalog with 10 sample titles
   (see `DatabaseSeeder.kt`) — no manual seeding required.

## Visual design plans (wireframes)

See `/wireframes` — low-fidelity screen wireframes covering the required
flows, provided as both SVG (editable) and PNG (for pasting into the
Word doc submission):

1. `01_catalog_screen` — search bar, two-column book grid, availability badges
2. `02_reserve_bottom_sheet` — modal bottom sheet with rental duration + Reserve
3. `03_reservations_dashboard` — active bookings with due-date status and
   Renew / Return / Cancel controls

## CRUD screenshots / GIFs

_Add real app screenshots or a short screen-recording GIF here (or in the
accompanying `StudName_MADB372_SF1.docx`) demonstrating:_
- _Browsing / searching the catalog_
- _Reserving a book (bottom sheet)_
- _Viewing the dashboard with an active booking_
- _Renew, Return, and Cancel actions_

## AI use disclosure

Per the AITLM for Task 1 (Amber — AI may be used for project work,
feedback, and editing), attach screenshots of any AI prompts and outputs
used while building this project, per the assignment checklist.

## Out of scope (per assignment spec)

- Firebase / REST APIs / cloud databases
- User authentication or multi-user support
- Payment processing for late fees
